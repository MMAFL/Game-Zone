let largeScenery = []
let smallScenery = []

export function setLargeScenery(data) {
   largeScenery = data
}

export function getLargeScenery() {
   return largeScenery
}

export function setSmallScenery(data) {
   smallScenery = data
}

export function getSmallScenery() {
   return smallScenery
}
