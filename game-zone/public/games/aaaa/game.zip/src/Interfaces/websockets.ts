export interface WebSocketMessage {
   type: string
   payload: any
}
