   // src/App.tsx
   import React from 'react';
   import SnakeGame from './components/SnakeGame';

   const App: React.FC = () => {
       return (
           <div>
               <SnakeGame />
           </div>
       );
   };

   export default App;