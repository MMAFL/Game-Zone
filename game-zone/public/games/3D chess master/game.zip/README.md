Multiplayer 3d chess game built with react-three-fiber and socket.io.

Live demo: https://chess-in-3d.herokuapp.com/

![Imgur](https://i.imgur.com/r9tBfim.png)
