module.exports = [
  {
    loader: 'file-loader',
    options: {
      name: '[path][name].[ext]'
    }
  }
];
