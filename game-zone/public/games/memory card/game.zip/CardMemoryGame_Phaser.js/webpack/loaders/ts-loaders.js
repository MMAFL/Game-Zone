module.exports = [
  {
    loader: 'ts-loader'
  }
];