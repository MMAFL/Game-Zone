module.exports = [
  {
    loader: 'file-loader',
    options: {
      outputPath: 'fonts'
    }
  }
];
