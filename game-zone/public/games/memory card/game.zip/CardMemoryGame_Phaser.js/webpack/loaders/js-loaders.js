module.exports = [
  {
    loader: 'babel-loader'
  }
];
