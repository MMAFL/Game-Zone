export default {
    screenWidth: 1280,
    screenHeight: 720,
    // backgroundColor: "#6e6666",
}